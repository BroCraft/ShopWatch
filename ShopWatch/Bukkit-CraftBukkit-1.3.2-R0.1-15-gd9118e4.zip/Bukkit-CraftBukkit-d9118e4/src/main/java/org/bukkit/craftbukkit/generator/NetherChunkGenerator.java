package org.bukkit.craftbukkit.generator;

import net.minecraft.server.World;

/**
 * This class is useless. Just fyi.
 */
public class NetherChunkGenerator extends NormalChunkGenerator {
    public NetherChunkGenerator(World world, long seed) {
        super(world, seed);
    }
}
