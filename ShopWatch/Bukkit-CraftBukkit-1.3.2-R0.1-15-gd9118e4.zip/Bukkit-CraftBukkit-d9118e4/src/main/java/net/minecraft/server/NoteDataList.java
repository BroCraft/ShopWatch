package net.minecraft.server;

import java.util.ArrayList;

// CraftBukkit - imported class because the constructor is package private

class NoteDataList extends ArrayList {

    private NoteDataList() {}

    NoteDataList(EmptyClass2 emptyclass2) {
        this();
    }
}
